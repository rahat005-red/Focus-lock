# FOCUS LOCK — Android starter project (v0.1)

A native Kotlin Android starter app for self-imposed daily app limits.

## Included
- Lists installed apps with launcher icons (including Facebook, YouTube, Instagram, TikTok, Free Fire, Chrome, WhatsApp when installed).
- Lets you select apps and set an allowance from 1 to 600 minutes per day.
- Locks configuration for 24 hours after saving.
- Uses Android Accessibility events to detect the foreground app, count active time, and show a full-screen lock page when an allowance is exhausted.
- Daily usage counters reset on the device's local calendar day.
- Includes a GitHub Actions workflow to build a debug APK in the cloud.

## Important limitations
- This download is the Android source project, not an APK.
- An ordinary Android app cannot make itself impossible to uninstall, force-stop, or have its Accessibility permission revoked. This MVP cannot guarantee tamper-proof enforcement.
- The Accessibility service only reads foreground package names; it does not inspect screen text or transmit data. The app requests no network permission.
- The app uses the device clock for its cooldown and daily reset; changing the clock can weaken the cooldown.
- Xiaomi/HyperOS battery management may stop background services. Set FOCUS LOCK battery use to **No restrictions** and allow autostart if that option exists.
- This is an early MVP, not a Play Store-ready release. Test it before relying on it for important restrictions.

## Build an APK using only your phone (GitHub Actions)
1. Download and extract this ZIP.
2. In your phone browser, create a new GitHub repository.
3. Upload all files and folders from this project to the repository's `main` branch (including the hidden `.github` folder).
4. Open the repository's **Actions** tab and select **Build FOCUS LOCK APK**.
5. Tap **Run workflow**. When it finishes, open the run and download the `focus-lock-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from your browser or file manager.

Alternatively, open the project in Android Studio on a computer with Android SDK Platform 35 and choose **Build > Build APK(s)**.

## Setup on your phone
1. Open FOCUS LOCK.
2. Tap **Enable app-monitoring accessibility** and enable FOCUS LOCK in Android Accessibility settings.
3. Return to FOCUS LOCK, choose the apps, set minutes, then tap **LOCK MY DAILY LIMITS**.
4. Keep Accessibility enabled. On Xiaomi, set battery use to **No restrictions** and allow autostart if available.

## Known MVP gaps
- First save is allowed immediately; later saves are blocked until 24 hours have elapsed.
- Usage is counted while the selected app is in the foreground, with minor timing inaccuracies possible around app transitions.
- System apps without launcher icons may not appear in the app list.
- For stronger enforcement, a device-owner / managed-device design is needed. That setup is more involved and can require provisioning or resetting the device.
