package com.focuslock.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
    private var blockedPackage: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        blockedPackage = intent.getStringExtra("blocked_package") ?: ""
        showLock()
    }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        blockedPackage = intent?.getStringExtra("blocked_package") ?: blockedPackage
        showLock()
    }
    private fun showLock() {
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(blockedPackage, 0)).toString() } catch (_: Exception) { "This app" }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48); setBackgroundColor(Color.rgb(17,24,39))
        }
        layout.addView(TextView(this).apply { text = "🔒  FOCUS LOCK"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        layout.addView(TextView(this).apply { text = "Daily limit reached"; textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 28, 0, 8) })
        layout.addView(TextView(this).apply { text = "$label is locked for today. Your allowance has been used. Go back to your study or take a break."; textSize = 16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 8, 0, 28) })
        layout.addView(Button(this).apply { text = "RETURN TO HOME SCREEN"; setOnClickListener { val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(home); finish() } })
        setContentView(layout)
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* Intentionally do not dismiss the limit screen with Back. */ }
}
