package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.Color
import android.text.InputType
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val chosen = linkedMapOf<String, EditText>()
    private val selected = linkedMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 15f, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(31, 41, 55)); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(24)); setBackgroundColor(Color.rgb(248,250,252)) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(text("FOCUS LOCK", 25f, true))
        root.addView(text("Protect your study time. Set a daily allowance for distracting apps.", 14f).apply { setPadding(0, dp(6), 0, dp(18)) })

        val access = Button(this).apply { text = "1. Enable app-monitoring accessibility"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        root.addView(access, match())
        root.addView(text("Find FOCUS LOCK in Accessibility settings and turn it on. This permission is required to detect when a limited app is open.", 13f).apply { setPadding(0, dp(4), 0, dp(14)) })

        val isAllowed = Policy.canConfigure(this)
        val state = if (Policy.configuredAt(this) == 0L) "Not configured yet" else if (isAllowed) "You can configure today's limits" else "Settings locked — next change in ${format(Policy.remainingMs(this))}"
        root.addView(text(state, 16f, true).apply { setPadding(0, dp(8), 0, dp(12)) })
        root.addView(text("2. Choose apps and daily minutes", 18f, true))
        root.addView(text("The app list below contains apps with a launcher icon. Select the ones you want to restrict. 'Other apps' means you can select any other installed app here.", 13f).apply { setPadding(0, dp(4), 0, dp(10)) })

        val targets = Policy.targets(this)
        val pm = packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to (it.loadLabel(pm)?.toString() ?: it.activityInfo.packageName) }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        val preferred = listOf("Facebook", "YouTube", "Instagram", "TikTok", "Free Fire", "Chrome", "WhatsApp")
        val ordered = apps.sortedWith(compareBy<Pair<String,String>> { if (preferred.any { p -> it.second.contains(p, true) }) 0 else 1 }.thenBy { it.second.lowercase() })
        ordered.forEach { (pkg, label) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            val cb = CheckBox(this).apply { text = label; textSize = 14f; isChecked = if (Policy.configuredAt(this@MainActivity) == 0L) preferred.any { label.contains(it, true) } else pkg in targets; isEnabled = isAllowed }
            val limit = EditText(this).apply { hint = "min"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 14f; setSingleLine(); setText(if (pkg in targets) Policy.limitMinutes(this@MainActivity, pkg).toString() else "30"); isEnabled = isAllowed; gravity = Gravity.CENTER; setEms(4) }
            row.addView(cb, LinearLayout.LayoutParams(0, dp(48), 1f)); row.addView(limit, LinearLayout.LayoutParams(dp(76), dp(48)))
            root.addView(row); selected[pkg] = cb; chosen[pkg] = limit
        }

        val save = Button(this).apply {
            text = if (isAllowed) "LOCK MY DAILY LIMITS" else "LIMITS ARE LOCKED"
            isEnabled = isAllowed
            setOnClickListener {
                val limits = linkedMapOf<String, Int>()
                selected.forEach { (pkg, cb) -> if (cb.isChecked) {
                    val mins = chosen[pkg]?.text?.toString()?.toIntOrNull()
                    if (mins == null || mins !in 1..600) { Toast.makeText(this@MainActivity, "Enter 1–600 minutes for ${cb.text}", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                    limits[pkg] = mins
                } }
                if (limits.isEmpty()) { Toast.makeText(this@MainActivity, "Select at least one app", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                if (Policy.saveConfiguration(this@MainActivity, limits)) {
                    Toast.makeText(this@MainActivity, "Limits locked for 24 hours", Toast.LENGTH_LONG).show(); render()
                } else { Toast.makeText(this@MainActivity, "Settings are still in cooldown", Toast.LENGTH_LONG).show(); render() }
            }
        }
        root.addView(save, match().apply { topMargin = dp(16) })
        root.addView(text("Important: Android requires you to enable the Accessibility service. Keep it enabled for blocking to work. A regular app cannot prevent you from disabling that permission, force-stopping, or uninstalling it.", 12f).apply { setPadding(0, dp(14), 0, 0) })
    }

    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun format(ms: Long): String = String.format("%02dh %02dm", TimeUnit.MILLISECONDS.toHours(ms), TimeUnit.MILLISECONDS.toMinutes(ms) % 60)
}
