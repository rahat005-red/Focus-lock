package com.focuslock.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Policy {
    private const val PREF = "focus_lock_policy"
    private const val CONFIGURED_AT = "configured_at"
    private const val TARGETS = "targets"
    private const val LIMIT_PREFIX = "limit_"
    private const val USAGE_PREFIX = "usage_"
    private const val DAY_KEY = "usage_day"
    private const val DAY_MS = 24L * 60L * 60L * 1000L

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun configuredAt(c: Context) = prefs(c).getLong(CONFIGURED_AT, 0L)
    fun canConfigure(c: Context) = configuredAt(c) == 0L || System.currentTimeMillis() - configuredAt(c) >= DAY_MS
    fun remainingMs(c: Context): Long = (DAY_MS - (System.currentTimeMillis() - configuredAt(c))).coerceAtLeast(0L)
    fun targets(c: Context): Set<String> = prefs(c).getStringSet(TARGETS, emptySet())?.toSet() ?: emptySet()
    fun limitMinutes(c: Context, pkg: String) = prefs(c).getInt(LIMIT_PREFIX + pkg, 30)

    fun saveConfiguration(c: Context, limits: Map<String, Int>): Boolean {
        if (!canConfigure(c)) return false
        val p = prefs(c)
        val editor = p.edit().putLong(CONFIGURED_AT, System.currentTimeMillis()).putStringSet(TARGETS, limits.keys.toSet())
        limits.forEach { (pkg, minutes) -> editor.putInt(LIMIT_PREFIX + pkg, minutes.coerceIn(1, 600)) }
        editor.apply()
        return true
    }

    private fun ensureToday(c: Context) {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val p = prefs(c)
        if (p.getString(DAY_KEY, "") != today) {
            val e = p.edit().putString(DAY_KEY, today)
            targets(c).forEach { e.putLong(USAGE_PREFIX + it, 0L) }
            e.apply()
        }
    }

    fun addUsage(c: Context, pkg: String, millis: Long) {
        ensureToday(c)
        val p = prefs(c)
        p.edit().putLong(USAGE_PREFIX + pkg, p.getLong(USAGE_PREFIX + pkg, 0L) + millis).apply()
    }

    fun usedMillis(c: Context, pkg: String): Long {
        ensureToday(c)
        return prefs(c).getLong(USAGE_PREFIX + pkg, 0L)
    }

    fun isBlocked(c: Context, pkg: String): Boolean {
        if (pkg !in targets(c)) return false
        return usedMillis(c, pkg) >= limitMinutes(c, pkg) * 60_000L
    }
}
