package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var foregroundPackage: String? = null
    private var lastTick = 0L
    private var lockShownFor: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val pkg = foregroundPackage
            if (pkg != null && pkg != packageName && pkg != "com.android.systemui") {
                if (lastTick > 0L) Policy.addUsage(this@FocusAccessibilityService, pkg, (now - lastTick).coerceAtMost(2_000L))
                if (Policy.isBlocked(this@FocusAccessibilityService, pkg) && lockShownFor != pkg) {
                    lockShownFor = pkg
                    val i = Intent(this@FocusAccessibilityService, LockActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("blocked_package", pkg)
                    startActivity(i)
                }
            }
            lastTick = now
            handler.postDelayed(this, 1_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastTick = System.currentTimeMillis()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            foregroundPackage = pkg
            if (pkg != lockShownFor) lockShownFor = null
            lastTick = System.currentTimeMillis()
            if (pkg != packageName && Policy.isBlocked(this, pkg)) {
                lockShownFor = pkg
                startActivity(Intent(this, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("blocked_package", pkg))
            }
        }
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}
